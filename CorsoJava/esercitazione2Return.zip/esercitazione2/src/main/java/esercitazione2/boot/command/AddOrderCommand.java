package esercitazione2.boot.command;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import esercitazione2.boot.entity.LibroEntity;
import esercitazione2.boot.model.OrderRequestModel;
import esercitazione2.boot.service.LibroServiceImpl;
import esercitazione2.boot.service.OrdineServiceImpl;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class AddOrderCommand {

	private final OrdineServiceImpl ordineServiceImpl;
	private final LibroServiceImpl libroServiceImpl;
	
	
	private OrderRequestModel orderRequestModel;

	public void setOrderRequestModel(OrderRequestModel orderRequestModel) {
		this.orderRequestModel = orderRequestModel;
	}

	public AddOrderCommand(OrdineServiceImpl ordineServiceImpl, LibroServiceImpl libroServiceImpl) {
		super();
		this.ordineServiceImpl = ordineServiceImpl;
		this.libroServiceImpl = libroServiceImpl;
	}
	
	public String execute()
	{
		LibroEntity book = libroServiceImpl.searchBook(orderRequestModel.idBook());
		return ordineServiceImpl.addNewOrder(orderRequestModel, book);	
	}
	
}