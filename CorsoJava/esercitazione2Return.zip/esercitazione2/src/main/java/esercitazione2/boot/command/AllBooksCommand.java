package esercitazione2.boot.command;

import java.util.List;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import esercitazione2.boot.response.dto.LibroDto;
import esercitazione2.boot.service.LibroServiceImpl;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class AllBooksCommand {

	private final LibroServiceImpl libroServiceImpl;

	private int numberPage;
	private int sizePage;
	
	public AllBooksCommand(LibroServiceImpl libroServiceImpl) {
		super();
		this.libroServiceImpl = libroServiceImpl;
	}
	
	public void setNumberPage(int numberPage) {
		this.numberPage = numberPage;
	}



	public void setSizePage(int sizePage) {
		this.sizePage = sizePage;
	}



	public List<LibroDto> execute()
	{   
		return libroServiceImpl.getAllBooks(numberPage, sizePage);
	}
}