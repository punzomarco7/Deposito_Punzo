package esercitazione2.boot.controller;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import esercitazione2.boot.command.AllBooksCommand;
import esercitazione2.boot.response.dto.LibroDto;

@RestController
@RequestMapping("/books")
public class LibroController {

	private final BeanFactory beanFactory;
	
	public LibroController(BeanFactory beanFactory) {
		super();
		this.beanFactory = beanFactory;
	}

	@GetMapping("/all/{numberPage}/{sizePage}")
	public ResponseEntity<List<LibroDto>> allBooks(@PathVariable int numberPage, @PathVariable int sizePage)
	{
		AllBooksCommand command = beanFactory.getBean(AllBooksCommand.class);
		command.setNumberPage(numberPage);
		command.setSizePage(sizePage);
		return ResponseEntity.ok(command.execute());
	}
	
	
}