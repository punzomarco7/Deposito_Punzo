package esercitazione2.boot.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import esercitazione2.boot.command.AddOrderCommand;
import esercitazione2.boot.model.OrderRequestModel;
import esercitazione2.boot.request.dto.OrderRequestDTO;

@RestController
@RequestMapping("/orders")
public class OrdiniController {

	private final ApplicationContext applicationContext;

	public OrdiniController(ApplicationContext applicationContext) {
		super();
		this.applicationContext = applicationContext;
	}
	
	@PostMapping("/add")
	public ResponseEntity<String> addOrder(@RequestBody OrderRequestDTO orderRequestDTO)
	{
		OrderRequestModel orderRequestModel = new OrderRequestModel(orderRequestDTO.idUser(), orderRequestDTO.idBook());
		AddOrderCommand command = applicationContext.getBean(AddOrderCommand.class);
		command.setOrderRequestModel(orderRequestModel);
		return ResponseEntity.ok(command.execute());
	}
	
}