package esercitazione2.boot.entity;

import esercitazione2.boot.enums.StatoLibro;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "LIBRO")
@Getter
@Setter
public class LibroEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "TITOLO")
	private String title;

	@Column(name = "COPERTINA")
    private String cover;

	@Column(name = "AUTORE")
    private String author;

    @Column(name = "CASA_EDITRICE")
    private String homeEdit;

    @Column(name = "CAPITOLO")
    private Integer chapter;

    @Column(name = "ISBN")
    private String isbn;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATO")
    private StatoLibro status;

    @Column(name = "GENERE")
    private String gender;

    @Column(name = "EDIZIONE")
    private Integer edition;

    @Column(name = "PAGINE")
    private Integer pages;

    @Column(name = "TASCABILE")
    private Boolean isPocketable;

    @Column(name = "RILEGATURA")
    private String rileg;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IDREPARTO")
    private RepartoEntity reparto;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ORDINE")
    private OrdineEntity ordine;
	
}