package esercitazione2.boot.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.CurrentTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "ORDINE")
@Getter
@Setter
@NoArgsConstructor
public class OrdineEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UTENTE")
    private UtenteEntity utente;

    @OneToMany(mappedBy = "ordine")
    @JsonIgnore
    private List<LibroEntity> libro;

    @Column(name = "DATA_INIZIO_NOLEGGIO")
    @CurrentTimestamp
    private LocalDateTime dataInizioNoleggio;

    @Column(name = "DATA_FINE_NOLEGGIO")
    private LocalDateTime dataFineNoleggio;
    
    @Column(name = "DATA_SCADENZA_NOLEGGIO")
    private LocalDateTime dataScadenzaNoleggio;
}