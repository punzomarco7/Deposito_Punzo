package esercitazione2.boot.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "REPARTO")
@Getter
@Setter
@NoArgsConstructor
public class RepartoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "SCAFFALE")
    private String rack;
    @Column(name = "SEZIONE")
    private String section;
    @Column(name = "COLONNA")
    private Integer column;
    @Column(name = "RIGA")
    private Integer row;
    @Column(name = "PIANO")
    private Integer plan;

    @OneToMany(mappedBy = "reparto")
    @JsonIgnore
    private List<LibroEntity> libri = new ArrayList<>();
}