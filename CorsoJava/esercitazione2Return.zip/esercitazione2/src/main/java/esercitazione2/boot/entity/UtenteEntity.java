package esercitazione2.boot.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "UTENTE")
@Getter
@Setter
@NoArgsConstructor
public class UtenteEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "NOME")
    private String name;
    @Column(name = "COGNOME")
    private String surname;

    @Column(name = "COD_TESSERA")
    private String codTessera;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "INDIRIZZO")
    private String address;

    @Column(name = "COD_FISCALE")
    private String codFiscale;

    @Column(name = "DATA_NASCITA")
    private String dateBirth;
    @Column(name = "TELEFONO")
    private String telephone;

    @OneToMany(mappedBy = "utente")
    @JsonIgnore
    private List<OrdineEntity> ordini = new ArrayList<>();
}
