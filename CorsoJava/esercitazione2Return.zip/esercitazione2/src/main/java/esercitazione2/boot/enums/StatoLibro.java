package esercitazione2.boot.enums;

public enum StatoLibro {

	DISPONIBILE("DISPONIBILE"),
	IN_PRESTITO("IN_PRESTITO");
	
	private String stato;

	private StatoLibro(String stato) {
		this.stato = stato;
	}
	
}