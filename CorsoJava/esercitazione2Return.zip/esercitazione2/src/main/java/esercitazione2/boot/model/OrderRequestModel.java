package esercitazione2.boot.model;

public record OrderRequestModel(Long idUser, Long idBook) {

}
