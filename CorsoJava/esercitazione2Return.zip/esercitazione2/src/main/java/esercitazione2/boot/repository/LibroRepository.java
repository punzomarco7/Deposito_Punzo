package esercitazione2.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import esercitazione2.boot.entity.LibroEntity;

@Repository
public interface LibroRepository extends JpaRepository<LibroEntity, Long>{

}