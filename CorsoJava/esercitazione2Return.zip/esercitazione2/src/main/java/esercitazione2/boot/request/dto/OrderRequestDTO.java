package esercitazione2.boot.request.dto;

public record OrderRequestDTO(Long idUser, Long idBook) {

}