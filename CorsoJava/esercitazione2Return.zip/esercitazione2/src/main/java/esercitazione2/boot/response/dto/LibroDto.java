package esercitazione2.boot.response.dto;

import esercitazione2.boot.enums.StatoLibro;

public record LibroDto(Long id, String titolo, String autore, String copertina, 
		                       String casaEditrice, Integer capitolo, String isbn, StatoLibro stato,
		                       String genere, Integer edizione, Integer pagine, Boolean tascabile, 
		                       String rilegatura, Long idReparto, Long idOrdine) {

}
