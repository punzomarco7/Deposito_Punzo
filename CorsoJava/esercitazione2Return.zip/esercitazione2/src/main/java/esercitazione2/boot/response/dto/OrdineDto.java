package esercitazione2.boot.response.dto;

import java.time.LocalDateTime;
import java.util.List;

public record OrdineDto(Long id, Long idUtente, List<LibroDto> lsBooks, LocalDateTime dataInizioNoleggio,
		LocalDateTime dataFineNoleggio, LocalDateTime dataScadenzaNoleggio )  {

}
