package esercitazione2.boot.response.dto;

import java.util.List;

import esercitazione2.boot.entity.LibroEntity;

public record RepartoDto(Long id, String scaffale, String sezione, Integer colonna, Integer riga, Integer piano, List<LibroEntity> lsBooks) {

}
