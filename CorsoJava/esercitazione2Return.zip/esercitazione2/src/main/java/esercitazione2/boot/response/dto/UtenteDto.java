package esercitazione2.boot.response.dto;

import java.util.List;

import esercitazione2.boot.entity.OrdineEntity;

public record UtenteDto(String name, String surname, String codTessera, String email,
						 String address, String codFiscale, String dateBirth, String telephone, List<OrdineEntity> lsOrders) {

}