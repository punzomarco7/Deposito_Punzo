package esercitazione2.boot.service;

import java.util.List;

import esercitazione2.boot.entity.LibroEntity;
import esercitazione2.boot.response.dto.LibroDto;

public sealed interface LibroService permits LibroServiceImpl {

	List<LibroDto> getAllBooks(int numberPage, int sizePage);
	
	LibroEntity searchBook(Long id);
}