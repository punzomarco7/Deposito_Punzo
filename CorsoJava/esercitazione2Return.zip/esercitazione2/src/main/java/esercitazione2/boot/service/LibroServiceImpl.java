package esercitazione2.boot.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import esercitazione2.boot.entity.LibroEntity;
import esercitazione2.boot.repository.LibroRepository;
import esercitazione2.boot.response.dto.LibroDto;

@Service
public final class LibroServiceImpl implements LibroService {

	private final LibroRepository libroRepository;

	public LibroServiceImpl(LibroRepository libroRepository) {
		super();
		this.libroRepository = libroRepository;
	}

	@Override
	public List<LibroDto> getAllBooks(int numberPage, int sizePage) {
		Pageable pageable = PageRequest.of(numberPage, sizePage);
		return libroRepository.findAll(pageable).stream()
				.map(e -> new LibroDto(e.getId(), e.getTitle(), e.getAuthor(), e.getCover(),
						                       e.getHomeEdit(), e.getChapter(), e.getIsbn(), e.getStatus(),
						                       e.getGender(), e.getEdition(), e.getPages(), e.getIsPocketable(), 
						                       e.getRileg(), e.getReparto().getId(), Objects.isNull(e.getOrdine()) ? null : e.getOrdine().getId()))
				.toList();
	}
	
	@Override
	public LibroEntity searchBook(Long id) {
		
		Optional<LibroEntity> bookEntity = libroRepository.findById(id);
		
		return bookEntity.isPresent() ? bookEntity.get() : null;
	}
	
}