package esercitazione2.boot.service;

import esercitazione2.boot.entity.LibroEntity;
import esercitazione2.boot.model.OrderRequestModel;

public sealed interface OrdineService permits OrdineServiceImpl{
	
	String addNewOrder(OrderRequestModel orderRequestModel, LibroEntity book );
	
}