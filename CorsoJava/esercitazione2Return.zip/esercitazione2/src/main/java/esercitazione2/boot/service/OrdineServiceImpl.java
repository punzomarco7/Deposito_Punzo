package esercitazione2.boot.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import esercitazione2.boot.entity.LibroEntity;
import esercitazione2.boot.entity.OrdineEntity;
import esercitazione2.boot.entity.UtenteEntity;
import esercitazione2.boot.model.OrderRequestModel;
import esercitazione2.boot.repository.OrdineRepository;

@Service
public final class OrdineServiceImpl implements OrdineService{

	private final OrdineRepository ordineRepository;
	
	public OrdineServiceImpl(OrdineRepository ordineRepository) {
		super();
		this.ordineRepository = ordineRepository;
	}

	@Override
	public String addNewOrder(OrderRequestModel orderRequestModel, LibroEntity book) {
		
		List<LibroEntity> lsBooks = new ArrayList<LibroEntity>();
		lsBooks.add(book);
		
		UtenteEntity user = new UtenteEntity();
		user.setId(orderRequestModel.idUser());
		user.setCodFiscale("CODFISCAL");
		user.setEmail("email");
		user.setCodTessera("TESS");
		user.setTelephone("345678953");
		
		OrdineEntity ordineEntity = new OrdineEntity();
		ordineEntity.setUtente(user);
		ordineEntity.setLibro(lsBooks);
		ordineEntity.setDataScadenzaNoleggio(LocalDateTime.now().plusDays(60));
		
		ordineRepository.saveAndFlush(ordineEntity);
		return "Salvataggio eseguito correttamente";
	}

}
