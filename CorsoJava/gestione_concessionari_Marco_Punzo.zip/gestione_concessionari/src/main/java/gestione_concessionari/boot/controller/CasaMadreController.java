package gestione_concessionari.boot.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import gestione_concessionari.boot.entity.CasaMadre;
import gestione_concessionari.boot.service.CasaMadreService;

import java.util.List;

@RestController
@RequestMapping("/api/case-madri")
public class CasaMadreController {

    private final CasaMadreService casaMadreService;

    public CasaMadreController(
            CasaMadreService casaMadreService) {

        this.casaMadreService = casaMadreService;
    }

    // POST - Inserimento
    @PostMapping("/create")
    public ResponseEntity<CasaMadre> crea(
            @RequestBody CasaMadre casaMadre) {

        CasaMadre nuova =
            casaMadreService.creaCasaMadre(casaMadre);

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(nuova);
    }

    // GET - Tutte le Case Madri
    @GetMapping("/all")
    public ResponseEntity<List<CasaMadre>> trovaTutte() {

        return ResponseEntity.ok(
            casaMadreService.trovaTutte()
        );
    }

    // GET - Casa Madre per ID
    @GetMapping("/{id}")
    public ResponseEntity<CasaMadre> trovaPerId(
            @PathVariable Long id) {

        return ResponseEntity.ok(
            casaMadreService.trovaPerId(id)
        );
    }

    // PUT - Modifica
    @PutMapping("/{id}")
    public ResponseEntity<CasaMadre> aggiorna(
            @PathVariable Long id,
            @RequestBody CasaMadre casaMadre) {

        return ResponseEntity.ok(
            casaMadreService.aggiornaCasaMadre(id, casaMadre)
        );
    }

    // DELETE - Eliminazione
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> elimina(
            @PathVariable Long id) {

        casaMadreService.eliminaCasaMadre(id);

        return ResponseEntity.noContent().build();
    }
}