package gestione_concessionari.boot.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import gestione_concessionari.boot.entity.Cliente;
import gestione_concessionari.boot.service.ClienteService;

import java.util.List;

@RestController
@RequestMapping("/api/clienti")
public class ClienteController {

    private final ClienteService clienteService;

    public ClienteController(
            ClienteService clienteService) {

        this.clienteService = clienteService;
    }

    // POST - Inserimento
    @PostMapping("/create")
    public ResponseEntity<Cliente> crea(
            @RequestBody Cliente cliente) {

        Cliente nuovo =
            clienteService.creaCliente(cliente);

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(nuovo);
    }

    // GET - Tutti i clienti
    @GetMapping("/all")
    public ResponseEntity<List<Cliente>> trovaTutti() {

        return ResponseEntity.ok(
            clienteService.trovaTutti()
        );
    }

    // GET - Cliente per ID
    @GetMapping("/{id}")
    public ResponseEntity<Cliente> trovaPerId(
            @PathVariable Long id) {

        return ResponseEntity.ok(
            clienteService.trovaPerId(id)
        );
    }

    // PUT - Modifica
    @PutMapping("/{id}")
    public ResponseEntity<Cliente> aggiorna(
            @PathVariable Long id,
            @RequestBody Cliente cliente) {

        return ResponseEntity.ok(
            clienteService.aggiornaCliente(id, cliente)
        );
    }

    // DELETE - Eliminazione
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> elimina(
            @PathVariable Long id) {

        clienteService.eliminaCliente(id);

        return ResponseEntity.noContent().build();
    }
}