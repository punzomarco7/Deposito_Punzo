package gestione_concessionari.boot.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import gestione_concessionari.boot.entity.Concessionario;
import gestione_concessionari.boot.service.ConcessionarioService;

import java.util.List;

@RestController
@RequestMapping("/api/concessionari")
public class ConcessionarioController {

    private final ConcessionarioService concessionarioService;

    public ConcessionarioController(
            ConcessionarioService concessionarioService) {

        this.concessionarioService = concessionarioService;
    }

    // POST - Inserimento
    @PostMapping("/create")
    public ResponseEntity<Concessionario> crea(
            @RequestBody Concessionario concessionario) {

        Concessionario nuovo =
            concessionarioService.creaConcessionario(concessionario);

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(nuovo);
    }

    // GET - Tutti i concessionari
    @GetMapping("/all")
    public ResponseEntity<List<Concessionario>> trovaTutti() {

        return ResponseEntity.ok(
            concessionarioService.trovaTutti()
        );
    }

    // GET - Concessionario per ID
    @GetMapping("/{id}")
    public ResponseEntity<Concessionario> trovaPerId(
            @PathVariable Long id) {

        return ResponseEntity.ok(
            concessionarioService.trovaPerId(id)
        );
    }

    // PUT - Modifica
    @PutMapping("/{id}")
    public ResponseEntity<Concessionario> aggiorna(
            @PathVariable Long id,
            @RequestBody Concessionario concessionario) {

        return ResponseEntity.ok(
            concessionarioService.aggiornaConcessionario(
                id, concessionario
            )
        );
    }

    // DELETE - Eliminazione
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> elimina(
            @PathVariable Long id) {

        concessionarioService.eliminaConcessionario(id);

        return ResponseEntity.noContent().build();
    }
}