package gestione_concessionari.boot.dto;
public class CasaMadreDto {

    private Long id;
    private String ragioneSociale;
    private Long numeroConcessionari;
    private Long numeroClienti;
    private Double fatturatoTotale;

    public CasaMadreDto(
            Long id,
            String ragioneSociale,
            Long numeroConcessionari,
            Long numeroClienti,
            Double fatturatoTotale) {

        this.id = id;
        this.ragioneSociale = ragioneSociale;
        this.numeroConcessionari = numeroConcessionari;
        this.numeroClienti = numeroClienti;
        this.fatturatoTotale = fatturatoTotale;
    }

    public Long getId() {
        return id;
    }

    public String getRagioneSociale() {
        return ragioneSociale;
    }

    public Long getNumeroConcessionari() {
        return numeroConcessionari;
    }

    public Long getNumeroClienti() {
        return numeroClienti;
    }

    public Double getFatturatoTotale() {
        return fatturatoTotale;
    }
}