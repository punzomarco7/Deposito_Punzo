package gestione_concessionari.boot.dto;
public class ConcessionarioDto {

    private Long id;
    private String nome;
    private Long numeroClienti;

    public ConcessionarioDto(
            Long id,
            String nome,
            Long numeroClienti) {

        this.id = id;
        this.nome = nome;
        this.numeroClienti = numeroClienti;
    }

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public Long getNumeroClienti() {
        return numeroClienti;
    }
}