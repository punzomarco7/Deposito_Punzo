package gestione_concessionari.boot.dto;

import java.math.BigDecimal;

public class FatturatoMedioDto {

    private BigDecimal fatturatoMedio;

    public FatturatoMedioDto(BigDecimal fatturatoMedio) {
        this.fatturatoMedio = fatturatoMedio;
    }

    public BigDecimal getFatturatoMedio() {
        return fatturatoMedio;
    }
}