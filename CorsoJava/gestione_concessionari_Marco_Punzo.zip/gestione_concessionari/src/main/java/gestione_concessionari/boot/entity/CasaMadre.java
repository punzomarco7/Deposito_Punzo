package gestione_concessionari.boot.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "casa_madre")
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({
    "hibernateLazyInitializer",
    "handler"
})
public class CasaMadre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(
        name = "ragione_sociale",
        nullable = false,
        length = 100
    )
    private String ragioneSociale;

    @Column(
        name = "sede_legale",
        nullable = false,
        length = 100
    )
    private String sedeLegale;

    @Column(
        nullable = false,
        length = 50
    )
    private String paese;

    @Column(name = "anno_fondazione")
    private Integer annoFondazione;

    @Column(
        name = "fatturato_annuo",
        precision = 15,
        scale = 2
    )
    private BigDecimal fatturatoAnnuo;

    // Relazione inversa con Concessionario
    @OneToMany(
        mappedBy = "casaMadre",
        fetch = FetchType.LAZY
    )
    @JsonIgnore
    private List<Concessionario> concessionari =
        new ArrayList<>();
}