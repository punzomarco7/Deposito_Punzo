package gestione_concessionari.boot.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "cliente")
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({
    "hibernateLazyInitializer",
    "handler"
})
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String nome;

    @Column(nullable = false, length = 50)
    private String cognome;

    @Column(
        unique = true,
        length = 100
    )
    private String email;

    @Column(length = 20)
    private String telefono;

    @CreationTimestamp
    @Column(
        name = "data_registrazione",
        nullable = false,
        updatable = false,
        columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
    )
    private LocalDateTime dataRegistrazione;

    // Relazione proprietaria con Concessionario
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
        name = "concessionario_id",
        nullable = false
    )
    private Concessionario concessionario;
}