package gestione_concessionari.boot.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "concessionario")
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({
    "hibernateLazyInitializer",
    "handler"
})
public class Concessionario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(nullable = false, length = 100)
    private String citta;

    @Column(length = 150)
    private String indirizzo;

    @Column(length = 20)
    private String telefono;

    @Column(precision = 15, scale = 2)
    private BigDecimal fatturato;

    // Relazione proprietaria con CasaMadre
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
        name = "casa_madre_id",
        nullable = false
    )
    private CasaMadre casaMadre;

    // Relazione inversa con Cliente
    @OneToMany(
        mappedBy = "concessionario",
        fetch = FetchType.LAZY
    )
    @JsonIgnore
    private List<Cliente> clienti = new ArrayList<>();
}