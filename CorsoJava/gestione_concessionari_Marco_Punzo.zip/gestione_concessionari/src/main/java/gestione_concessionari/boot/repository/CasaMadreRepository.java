package gestione_concessionari.boot.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import gestione_concessionari.boot.dto.CasaMadreDto;
import gestione_concessionari.boot.entity.CasaMadre;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface CasaMadreRepository
        extends JpaRepository<CasaMadre, Long> {
	 Optional<CasaMadre> findByRagioneSociale(
		        String ragioneSociale
		    );

		    boolean existsByRagioneSociale(String ragioneSociale);

		    List<CasaMadre> findByPaese(String paese);

		    List<CasaMadre> findByAnnoFondazioneLessThan(
		        Integer anno
		    );
		    @Query("""
		    	    SELECT c
		    	    FROM CasaMadre c
		    	    WHERE c.paese = :paese
		    	    AND c.fatturatoAnnuo > :fatturato
		    	""")
		    	List<CasaMadre> ricercaPerPaeseEFatturato(
		    	    @Param("paese") String paese,
		    	    @Param("fatturato") BigDecimal fatturato
		    	);
		    @Query("""
		    	    SELECT new gestione_concessionari.boot.dto.CasaMadreDto(
		    	        cm.id,
		    	        cm.ragioneSociale,
		    	        COUNT(c.id),
		    	        0L,
		    	        0.0
		    	    )
		    	    FROM CasaMadre cm
		    	    LEFT JOIN cm.concessionari c
		    	    GROUP BY cm.id, cm.ragioneSociale
		    	""")
		    	List<CasaMadreDto> contaConcessionariPerCasaMadre();
}