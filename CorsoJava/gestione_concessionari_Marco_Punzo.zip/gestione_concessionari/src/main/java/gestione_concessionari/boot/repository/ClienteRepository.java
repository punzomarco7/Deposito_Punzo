package gestione_concessionari.boot.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import gestione_concessionari.boot.entity.Cliente;

import java.util.List;
import java.util.Optional;

public interface ClienteRepository
        extends JpaRepository<Cliente, Long> {
	List<Cliente> findByNome(String nome);

    List<Cliente> findByCognome(String cognome);

    Optional<Cliente> findByEmail(String email);

    List<Cliente> findByNomeAndCognome(
        String nome,
        String cognome
    );

    boolean existsByConcessionarioId(Long id);

    boolean existsByEmail(String email);

    boolean existsByEmailAndIdNot(String email, Long id);
    @Query("""
    	    SELECT cl
    	    FROM Cliente cl
    	    JOIN cl.concessionario c
    	    WHERE c.id = :id
    	""")
    	List<Cliente> findClientiByConcessionarioId(
    	    @Param("id") Long id
    	);
    @Query("""
    	    SELECT cl
    	    FROM Cliente cl
    	    JOIN cl.concessionario c
    	    JOIN c.casaMadre cm
    	    WHERE cm.id = :id
    	""")
    	List<Cliente> findClientiByCasaMadreId(
    	    @Param("id") Long id
    	);
    @Query("""
    	    SELECT cl
    	    FROM Cliente cl
    	    JOIN cl.concessionario c
    	    WHERE c.citta = :citta
    	""")
    	List<Cliente> findClientiByCittaConcessionario(
    	    @Param("citta") String citta
    	);
    @Query("""
    	    SELECT cl
    	    FROM Cliente cl
    	    JOIN cl.concessionario c
    	    JOIN c.casaMadre cm
    	    WHERE cm.paese = :paese
    	""")
    	List<Cliente> findClientiByPaeseCasaMadre(
    	    @Param("paese") String paese
    	);
}