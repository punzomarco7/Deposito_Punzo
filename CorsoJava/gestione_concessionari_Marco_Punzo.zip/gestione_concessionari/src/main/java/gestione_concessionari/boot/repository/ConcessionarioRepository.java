package gestione_concessionari.boot.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import gestione_concessionari.boot.dto.ConcessionarioDto;
import gestione_concessionari.boot.entity.Concessionario;

import java.math.BigDecimal;
import java.util.List;

public interface ConcessionarioRepository
        extends JpaRepository<Concessionario, Long> {
	List<Concessionario> findByCitta(String citta);

    List<Concessionario> findByFatturatoGreaterThan(
        BigDecimal fatturato
    );

    List<Concessionario> findByFatturatoBetween(
        BigDecimal min,
        BigDecimal max
    );

    boolean existsByCasaMadreId(Long id);

    boolean existsByCasaMadreIdAndIdNot(
        Long casaMadreId,
        Long id
    );
    @Query("""
    	    SELECT c
    	    FROM Concessionario c
    	    JOIN c.casaMadre cm
    	    WHERE cm.ragioneSociale = :ragioneSociale
    	""")
    	List<Concessionario> findByRagioneSocialeCasaMadre(
    	    @Param("ragioneSociale") String ragioneSociale
    	);
    @Query("""
    	    SELECT new gestione_concessionari.boot.dto.ConcessionarioDto(
    	        c.id,
    	        c.nome,
    	        COUNT(cl.id)
    	    )
    	    FROM Concessionario c
    	    LEFT JOIN c.clienti cl
    	    GROUP BY c.id, c.nome
    	""")
    	List<ConcessionarioDto> contaClientiPerConcessionario();
}