package gestione_concessionari.boot.service;
import org.springframework.stereotype.Service;

import gestione.concessionari.boot.exception.BadRequestException;
import gestione.concessionari.boot.exception.ResourceNotFoundException;
import gestione_concessionari.boot.entity.CasaMadre;
import gestione_concessionari.boot.repository.CasaMadreRepository;
import gestione_concessionari.boot.repository.ConcessionarioRepository;

import java.util.List;

@Service
public class CasaMadreService {

    private final CasaMadreRepository casaMadreRepository;
    private final ConcessionarioRepository concessionarioRepository;

    public CasaMadreService(
            CasaMadreRepository casaMadreRepository,
            ConcessionarioRepository concessionarioRepository) {

        this.casaMadreRepository = casaMadreRepository;
        this.concessionarioRepository = concessionarioRepository;
    }

    // CREATE
    public CasaMadre creaCasaMadre(CasaMadre casaMadre) {

        if (casaMadre.getRagioneSociale() == null ||
            casaMadre.getRagioneSociale().isBlank()) {

            throw new BadRequestException(
                "La ragione sociale è obbligatoria"
            );
        }

        if (casaMadre.getSedeLegale() == null ||
            casaMadre.getSedeLegale().isBlank()) {

            throw new BadRequestException(
                "La sede legale è obbligatoria"
            );
        }

        if (casaMadre.getPaese() == null ||
            casaMadre.getPaese().isBlank()) {

            throw new BadRequestException(
                "Il paese è obbligatorio"
            );
        }

        casaMadre.setId(null);

        return casaMadreRepository.save(casaMadre);
    }

    // READ ALL
    public List<CasaMadre> trovaTutte() {

        return casaMadreRepository.findAll();
    }

    // READ BY ID
    public CasaMadre trovaPerId(Long id) {

        return casaMadreRepository.findById(id)
            .orElseThrow(() ->
                new ResourceNotFoundException(
                    "Casa Madre non trovata con ID: " + id
                )
            );
    }

    // UPDATE
    public CasaMadre aggiornaCasaMadre(
            Long id,
            CasaMadre datiNuovi) {

        CasaMadre casaMadre = trovaPerId(id);

        if (datiNuovi.getRagioneSociale() == null ||
            datiNuovi.getRagioneSociale().isBlank()) {

            throw new BadRequestException(
                "La ragione sociale è obbligatoria"
            );
        }

        if (datiNuovi.getSedeLegale() == null ||
            datiNuovi.getSedeLegale().isBlank()) {

            throw new BadRequestException(
                "La sede legale è obbligatoria"
            );
        }

        if (datiNuovi.getPaese() == null ||
            datiNuovi.getPaese().isBlank()) {

            throw new BadRequestException(
                "Il paese è obbligatorio"
            );
        }

        casaMadre.setRagioneSociale(
            datiNuovi.getRagioneSociale()
        );

        casaMadre.setSedeLegale(
            datiNuovi.getSedeLegale()
        );

        casaMadre.setPaese(
            datiNuovi.getPaese()
        );

        casaMadre.setAnnoFondazione(
            datiNuovi.getAnnoFondazione()
        );

        casaMadre.setFatturatoAnnuo(
            datiNuovi.getFatturatoAnnuo()
        );

        return casaMadreRepository.save(casaMadre);
    }

    // DELETE
    public void eliminaCasaMadre(Long id) {

        CasaMadre casaMadre = trovaPerId(id);

        boolean haConcessionari =
            concessionarioRepository.existsByCasaMadreId(id);

        if (haConcessionari) {

            throw new BadRequestException(
                "Impossibile eliminare la Casa Madre: "
                + "sono presenti concessionari associati"
            );
        }

        casaMadreRepository.delete(casaMadre);
    }
}