package gestione_concessionari.boot.service;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gestione.concessionari.boot.exception.BadRequestException;
import gestione.concessionari.boot.exception.ResourceNotFoundException;
import gestione_concessionari.boot.entity.Cliente;
import gestione_concessionari.boot.entity.Concessionario;
import gestione_concessionari.boot.repository.ClienteRepository;
import gestione_concessionari.boot.repository.ConcessionarioRepository;

import java.util.List;

@Service
@Transactional
public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final ConcessionarioRepository concessionarioRepository;

    public ClienteService(
            ClienteRepository clienteRepository,
            ConcessionarioRepository concessionarioRepository) {

        this.clienteRepository = clienteRepository;
        this.concessionarioRepository = concessionarioRepository;
    }

    // CREATE
    public Cliente creaCliente(Cliente cliente) {

        if (cliente.getNome() == null ||
            cliente.getNome().isBlank()) {

            throw new BadRequestException(
                "Il nome del cliente è obbligatorio"
            );
        }

        if (cliente.getCognome() == null ||
            cliente.getCognome().isBlank()) {

            throw new BadRequestException(
                "Il cognome del cliente è obbligatorio"
            );
        }

        if (cliente.getEmail() != null &&
            clienteRepository.existsByEmail(cliente.getEmail())) {

            throw new BadRequestException(
                "Email già utilizzata da un altro cliente"
            );
        }

        if (cliente.getConcessionario() == null ||
            cliente.getConcessionario().getId() == null) {

            throw new BadRequestException(
                "È necessario indicare un concessionario"
            );
        }

        Long concessionarioId =
            cliente.getConcessionario().getId();

        Concessionario concessionario =
            concessionarioRepository.findById(concessionarioId)
                .orElseThrow(() ->
                    new ResourceNotFoundException(
                        "Concessionario non trovato con ID: "
                        + concessionarioId
                    )
                );

        cliente.setId(null);
        cliente.setConcessionario(concessionario);

        return clienteRepository.save(cliente);
    }

    // READ ALL
    @Transactional(readOnly = true)
    public List<Cliente> trovaTutti() {

        return clienteRepository.findAll();
    }

    // READ BY ID
    @Transactional(readOnly = true)
    public Cliente trovaPerId(Long id) {

        return clienteRepository.findById(id)
            .orElseThrow(() ->
                new ResourceNotFoundException(
                    "Cliente non trovato con ID: " + id
                )
            );
    }

    // UPDATE
    public Cliente aggiornaCliente(
            Long id,
            Cliente datiNuovi) {

        Cliente cliente = trovaPerId(id);

        if (datiNuovi.getNome() == null ||
            datiNuovi.getNome().isBlank()) {

            throw new BadRequestException(
                "Il nome del cliente è obbligatorio"
            );
        }

        if (datiNuovi.getCognome() == null ||
            datiNuovi.getCognome().isBlank()) {

            throw new BadRequestException(
                "Il cognome del cliente è obbligatorio"
            );
        }

        if (datiNuovi.getEmail() != null &&
            clienteRepository.existsByEmailAndIdNot(
                datiNuovi.getEmail(), id)) {

            throw new BadRequestException(
                "Email già utilizzata da un altro cliente"
            );
        }

        if (datiNuovi.getConcessionario() == null ||
            datiNuovi.getConcessionario().getId() == null) {

            throw new BadRequestException(
                "È necessario indicare un concessionario"
            );
        }

        Long concessionarioId =
            datiNuovi.getConcessionario().getId();

        Concessionario concessionario =
            concessionarioRepository.findById(concessionarioId)
                .orElseThrow(() ->
                    new ResourceNotFoundException(
                        "Concessionario non trovato con ID: "
                        + concessionarioId
                    )
                );

        cliente.setNome(datiNuovi.getNome());
        cliente.setCognome(datiNuovi.getCognome());
        cliente.setEmail(datiNuovi.getEmail());
        cliente.setTelefono(datiNuovi.getTelefono());

        // Possibilità di cambiare concessionario
        cliente.setConcessionario(concessionario);

        return clienteRepository.save(cliente);
    }

    // DELETE
    public void eliminaCliente(Long id) {

        Cliente cliente = trovaPerId(id);

        clienteRepository.delete(cliente);
    }
}