package gestione_concessionari.boot.service;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gestione.concessionari.boot.exception.BadRequestException;
import gestione.concessionari.boot.exception.ResourceNotFoundException;
import gestione_concessionari.boot.entity.CasaMadre;
import gestione_concessionari.boot.entity.Concessionario;
import gestione_concessionari.boot.repository.CasaMadreRepository;
import gestione_concessionari.boot.repository.ClienteRepository;
import gestione_concessionari.boot.repository.ConcessionarioRepository;

import java.util.List;

@Service
@Transactional
public class ConcessionarioService {

    private final ConcessionarioRepository concessionarioRepository;
    private final CasaMadreRepository casaMadreRepository;
    private final ClienteRepository clienteRepository;

    public ConcessionarioService(
            ConcessionarioRepository concessionarioRepository,
            CasaMadreRepository casaMadreRepository,
            ClienteRepository clienteRepository) {

        this.concessionarioRepository = concessionarioRepository;
        this.casaMadreRepository = casaMadreRepository;
        this.clienteRepository = clienteRepository;
    }

    // CREATE
    public Concessionario creaConcessionario(
            Concessionario concessionario) {

        if (concessionario.getNome() == null ||
            concessionario.getNome().isBlank()) {

            throw new BadRequestException(
                "Il nome del concessionario è obbligatorio"
            );
        }

        if (concessionario.getCitta() == null ||
            concessionario.getCitta().isBlank()) {

            throw new BadRequestException(
                "La città è obbligatoria"
            );
        }

        if (concessionario.getCasaMadre() == null ||
            concessionario.getCasaMadre().getId() == null) {

            throw new BadRequestException(
                "È necessario indicare una Casa Madre"
            );
        }

        Long casaMadreId =
            concessionario.getCasaMadre().getId();

        CasaMadre casaMadre = casaMadreRepository
            .findById(casaMadreId)
            .orElseThrow(() ->
                new ResourceNotFoundException(
                    "Casa Madre non trovata con ID: " + casaMadreId
                )
            );

        concessionario.setId(null);
        concessionario.setCasaMadre(casaMadre);

        return concessionarioRepository.save(concessionario);
    }

    // READ ALL
    @Transactional(readOnly = true)
    public List<Concessionario> trovaTutti() {

        return concessionarioRepository.findAll();
    }

    // READ BY ID
    @Transactional(readOnly = true)
    public Concessionario trovaPerId(Long id) {

        return concessionarioRepository.findById(id)
            .orElseThrow(() ->
                new ResourceNotFoundException(
                    "Concessionario non trovato con ID: " + id
                )
            );
    }

    // UPDATE
    public Concessionario aggiornaConcessionario(
            Long id,
            Concessionario datiNuovi) {

        Concessionario concessionario = trovaPerId(id);

        if (datiNuovi.getNome() == null ||
            datiNuovi.getNome().isBlank()) {

            throw new BadRequestException(
                "Il nome del concessionario è obbligatorio"
            );
        }

        if (datiNuovi.getCitta() == null ||
            datiNuovi.getCitta().isBlank()) {

            throw new BadRequestException(
                "La città è obbligatoria"
            );
        }

        if (datiNuovi.getCasaMadre() == null ||
            datiNuovi.getCasaMadre().getId() == null) {

            throw new BadRequestException(
                "È necessario indicare una Casa Madre"
            );
        }

        Long casaMadreId =
            datiNuovi.getCasaMadre().getId();

        CasaMadre casaMadre = casaMadreRepository
            .findById(casaMadreId)
            .orElseThrow(() ->
                new ResourceNotFoundException(
                    "Casa Madre non trovata con ID: " + casaMadreId
                )
            );

        concessionario.setNome(datiNuovi.getNome());
        concessionario.setCitta(datiNuovi.getCitta());
        concessionario.setIndirizzo(datiNuovi.getIndirizzo());
        concessionario.setTelefono(datiNuovi.getTelefono());
        concessionario.setFatturato(datiNuovi.getFatturato());

        // Possibilità di cambiare Casa Madre
        concessionario.setCasaMadre(casaMadre);

        return concessionarioRepository.save(concessionario);
    }

    // DELETE
    public void eliminaConcessionario(Long id) {

        Concessionario concessionario = trovaPerId(id);

        boolean haClienti =
            clienteRepository.existsByConcessionarioId(id);

        if (haClienti) {

            throw new BadRequestException(
                "Impossibile eliminare il concessionario: "
                + "sono presenti clienti associati"
            );
        }

        concessionarioRepository.delete(concessionario);
    }
}