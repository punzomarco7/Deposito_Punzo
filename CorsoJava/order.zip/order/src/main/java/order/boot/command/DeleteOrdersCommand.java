package order.boot.command;

import org.springframework.stereotype.Component;

import order.boot.model.response.OrderResponse;
import order.boot.service.OrdersService;



@Component
public class DeleteOrdersCommand {
	private final OrdersService ordersService;
	 private  Long id;

	    public DeleteOrdersCommand(OrdersService ordersService) {
	        this.ordersService= ordersService;
	    }

	   
	  
		
	    public void setId(Long id) {
			this.id = id;
		}




		public String execute()
		{
			return ordersService.eliminaOrdine(id);
		}
}
