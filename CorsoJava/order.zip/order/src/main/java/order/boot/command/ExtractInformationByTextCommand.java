package order.boot.command;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import order.boot.model.request.ChatRequestModel;
import order.boot.model.response.Persona;
import order.boot.service.OrderAIService;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class ExtractInformationByTextCommand {
    private final OrderAIService aiservice;
    
    private ChatRequestModel chatRequestModel;
    
    public void setChatRequestModel(ChatRequestModel chatRequestModel) {
    	this.chatRequestModel = chatRequestModel;
    }
    
    public ExtractInformationByTextCommand(OrderAIService aiService) {
    	super();
    	this.aiservice = aiService;
    }
    
    public Persona execute()
    {
    	return aiservice.extractDataPerson(chatRequestModel.question());
    }
}
