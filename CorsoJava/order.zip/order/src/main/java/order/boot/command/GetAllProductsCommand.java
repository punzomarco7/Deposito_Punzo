package order.boot.command;

import java.util.List;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import order.boot.dto.ProductsResponseDto;
import order.boot.service.OrderProductsService;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class GetAllProductsCommand {
	
	private final OrderProductsService productsService;
	
	public GetAllProductsCommand(OrderProductsService productsService) {
		super();
		this.productsService = productsService;
	}
	
	public List<ProductsResponseDto> execute()
	{
		return productsService.findAllProduct();
	}
	

}
