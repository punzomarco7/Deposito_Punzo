package order.boot.command;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import order.boot.model.request.ChatRequestModel;
import order.boot.service.OrderAIService;


	@Component
	@Scope(BeanDefinition.SCOPE_PROTOTYPE)
	public class OrderChatMemoryAICommand {

		private final OrderAIService aiService;
		
		private ChatRequestModel chatRequestModel;

		public void setChatRequestModel(ChatRequestModel chatRequestModel) {
			this.chatRequestModel = chatRequestModel;
		}

		public OrderChatMemoryAICommand(OrderAIService aiService) {
			super();
			this.aiService = aiService;
		}
		
		public String execute()
		{
			return aiService.testMemoryAI(chatRequestModel.question());
		}
	}
			
	

