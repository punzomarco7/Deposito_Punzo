package order.boot.command;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import order.boot.model.request.OrderRequestModel;
import order.boot.model.response.OrderResponse;
import order.boot.service.OrdersService;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class OrderCommand {
	private final OrdersService ordersService;
	private Long id;
	
	public void setId(Long id) {
		this.id = id;
	}
	public OrderCommand(OrdersService ordersService) {
		super();
		this.ordersService = ordersService;
	}
	
	public OrderResponse execute()
	{
		return ordersService.getOrderById(id);
	}
	
		
	

}
