package order.boot.command;

import org.springframework.stereotype.Component;

import order.boot.model.request.ChatRequestModel;
import order.boot.service.OrderAIService;
@Component
public class OrderRagAICommand {
	private final OrderAIService aiService;

	private ChatRequestModel chatRequestModel;

	public void setChatRequestModel(ChatRequestModel chatRequestModel) {
	this.chatRequestModel = chatRequestModel;
	}

	public OrderRagAICommand(OrderAIService aiService) {
	super();
	this.aiService = aiService;
	}

	public String execute()
	{
	return aiService.askPolicy(chatRequestModel.question());
	}

}
