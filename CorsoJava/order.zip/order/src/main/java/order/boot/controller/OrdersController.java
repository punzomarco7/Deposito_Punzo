package order.boot.controller;
import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import order.boot.command.AddOrderCommand;
import order.boot.command.DeleteOrdersCommand;
import order.boot.command.ExtractInformationByTextCommand;
import order.boot.command.GetAllProductsCommand;
import order.boot.command.OrderAICommand;
import order.boot.command.OrderChatMemoryAICommand;
import order.boot.command.OrderCommand;
import order.boot.command.OrderRagAICommand;
import order.boot.command.RecoveryAllOrdersCommand;
import order.boot.dto.ProductsResponseDto;
import order.boot.model.request.ChatRequest;
import order.boot.model.request.ChatRequestModel;
import order.boot.model.request.OrderRequest;
import order.boot.model.request.OrderRequestModel;
import order.boot.model.response.InformationOrderResponse;
import order.boot.model.response.OrderResponse;
import order.boot.model.response.Persona;
import order.boot.repository.OrdersRepository;
import order.boot.service.OrdersService;

@RestController
@RequestMapping("/orders")
public class OrdersController {
         private final BeanFactory beanFactory;
         
         public OrdersController(BeanFactory beanFactory) {
        	 super();
        	 this.beanFactory= beanFactory;
         }
        	 @GetMapping("/all")
        	 public ResponseEntity<List<OrderResponse>> recoveryAllOrders()
        	 {
        		 RecoveryAllOrdersCommand command= beanFactory.getBean(RecoveryAllOrdersCommand.class);
        		 return ResponseEntity.ok(command.execute());
        	 }
        	 
        	 @GetMapping("/order/{id}")
        	 public ResponseEntity<OrderResponse> getOrderById(@PathVariable Long id)
        	 {
        		 OrderCommand command = beanFactory.getBean(OrderCommand.class);
        		 command.setId(id);
        		 return ResponseEntity.ok(command.execute());
       	 }
       	 @PostMapping("/new")
       	 public ResponseEntity<List<InformationOrderResponse>> addOrder(@RequestBody OrderRequest orderRequest)
        	 {
       		 OrderRequestModel model = new OrderRequestModel(orderRequest.lsIdProduct());
        		 AddOrderCommand command = beanFactory.getBean(AddOrderCommand.class);
        		 command.setOrderRequestModel(model);
        		 return ResponseEntity.ok(command.execute());
        		 
       	 }
       	 
       	 @GetMapping("/product/available")
       	 public ResponseEntity<List<ProductsResponseDto>> getAllProducts()
       	 {
       		 GetAllProductsCommand command= beanFactory.getBean(GetAllProductsCommand.class);
       		 return ResponseEntity.ok(command.execute());
       	 }
       	 
       	 
         
       	@DeleteMapping("/{id}")
       	public ResponseEntity<String> eliminaOrdine(@PathVariable Long id) {

       	    DeleteOrdersCommand command = beanFactory.getBean(DeleteOrdersCommand.class);
       	 command.setId(id);
       	 return ResponseEntity.ok(command.execute());
       	}
       	@PostMapping("chat/ai")
    	public ResponseEntity<String> executeQuestionAI(@RequestBody ChatRequest chatRequest)
    	{
    		ChatRequestModel request = new ChatRequestModel(chatRequest.request());
    		OrderAICommand command = beanFactory.getBean(OrderAICommand.class);
    		command.setChatRequestModel(request);
    		return ResponseEntity.ok(command.execute());
    		
    	}
       	@PostMapping("chat/structured")
       	public ResponseEntity<Persona> executeStructureOutputAI(@RequestBody ChatRequest chatRequest)
       	{
       		ChatRequestModel request = new ChatRequestModel(chatRequest.request());
       		ExtractInformationByTextCommand command = beanFactory.getBean(ExtractInformationByTextCommand.class);
       		command.setChatRequestModel(request);
       		return ResponseEntity.ok(command.execute());
       	}
       	@PostMapping("chat/memory")
    	public ResponseEntity<String> extractByChatMemory(@RequestBody ChatRequest chatRequest)
    	{
    		ChatRequestModel request = new ChatRequestModel(chatRequest.request());
    		OrderChatMemoryAICommand command = beanFactory.getBean(OrderChatMemoryAICommand.class);
    		command.setChatRequestModel(request);
    		return ResponseEntity.ok(command.execute());
    	}
       	@PostMapping("chat/rag")
    	public ResponseEntity<String> getInfoPolicySociety(@RequestBody ChatRequest chatRequest)
    	{
    		ChatRequestModel request = new ChatRequestModel(chatRequest.request());
    		OrderRagAICommand command = beanFactory.getBean(OrderRagAICommand.class);
    		command.setChatRequestModel(request);
    		return ResponseEntity.ok(command.execute());
    	}	

}
