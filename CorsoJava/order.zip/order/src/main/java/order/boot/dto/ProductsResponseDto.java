package order.boot.dto;

import java.math.BigDecimal;
public record ProductsResponseDto(Long Id, String name, BigDecimal price, Integer amount) {

}
