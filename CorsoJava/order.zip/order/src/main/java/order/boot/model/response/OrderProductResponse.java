package order.boot.model.response;

import java.math.BigDecimal;

public record OrderProductResponse(String name, BigDecimal price, Integer amount) {

}
