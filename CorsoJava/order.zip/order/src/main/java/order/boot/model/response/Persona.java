package order.boot.model.response;

public record Persona(
		String nome,
		String cognome,
		Integer eta,
		String Professione
		) {

}
