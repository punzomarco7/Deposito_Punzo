package order.boot.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import order.boot.entity.OrdersEntity;

@Repository

public interface OrdersRepository extends JpaRepository<OrdersEntity, Long> {

 
}
