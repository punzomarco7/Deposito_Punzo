package order.boot.service;

import org.springframework.stereotype.Service;

import order.boot.model.response.Persona;
import order.boot.tools.OrderToolAI;

import java.util.UUID;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.vectorstore.VectorStore;
@Service
public class OrderAIService {

	private final ChatClient chatClient;
	private String conversationId = UUID.randomUUID().toString();

	public OrderAIService(ChatClient.Builder chatClient, OrderToolAI orderToolAI, ChatMemory chatMemory, VectorStore vectorStore) {
		super();
		this.chatClient = chatClient.defaultTools(orderToolAI)
									.defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
						            .defaultAdvisors(advisor -> advisor.param(
						                        ChatMemory.CONVERSATION_ID,
						                        conversationId
						                    ))
						            .defaultAdvisors(QuestionAnswerAdvisor.builder(vectorStore).build())
									.build();
		
	}
	public String askPolicy(String question) {

        return chatClient.prompt()
                .system("""
                    Sei un assistente aziendale.
                    Rispondi alle domande relative alle
                    procedure ferie utilizzando esclusivamente
                    le informazioni presenti nei documenti
                    recuperati.

                    Se l'informazione non è presente,
                    dichiara che non è disponibile
                    nella documentazione aziendale.
                    """)
                .user(question)
                .call()
                .content();
    }


	
	public String getResponseByAI(String question)
	{
		return chatClient.prompt()
				         .user(question)
				         .call()
				         .content();
	}
	public Persona extractDataPerson(String text)
	{
		return chatClient.prompt()
				.user(u -> u.text("""
		                Estrai nome, cognome, età e professione dal testo.
		                Se un dato non è presente, usa null.
		                Non inventare informazioni.

		                Testo: {text}
		                """).param("text",text))
				        .call()
		                .entity(Persona.class);
	}
	public String testMemoryAI(String question)
	{	
		return chatClient.prompt()
		          .user(question)
	              .call()
	              .content();
	}
}
