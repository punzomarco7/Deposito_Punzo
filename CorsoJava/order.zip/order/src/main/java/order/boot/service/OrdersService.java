package order.boot.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import order.boot.command.DeleteOrdersCommand;
import order.boot.entity.OrdersEntity;
import order.boot.model.response.OrderResponse;
import order.boot.repository.OrdersRepository;

@Service
public class OrdersService {
	
	private final OrdersRepository ordersRepository;

	
	public OrdersService(OrdersRepository ordersRepository) {
		super();
		this.ordersRepository = ordersRepository;
	}
	
	public List<OrderResponse> getAllOrders() {
		List<OrdersEntity> entity = ordersRepository.findAll();
		
		return entity.stream().map(map ->
		    new OrderResponse(
		    		map.getId(),
		    		map.getLocalDateTime(),
		    		map.getTotal(),
		    		map.getProducts()
		    		))
				.toList();
	}
	
	public OrderResponse getOrderById(Long id)
	{
		Optional<OrdersEntity> entity = ordersRepository.findById(id);
		return entity.isPresent() ? new OrderResponse(id,entity.get().getLocalDateTime(),
				                                         entity.get().getTotal(), entity.get().getProducts())
				: new OrderResponse(null,null,null,null);
	}
    public OrderResponse saveNewOrder(BigDecimal totale, String lsIdProducts)
    {
    	OrdersEntity createEntity = new OrdersEntity();
    	createEntity.setProducts(lsIdProducts);
    	createEntity.setTotal(totale);
    	OrdersEntity entity = ordersRepository.saveAndFlush(createEntity);
    	
    	return new OrderResponse(entity.getId(),entity.getLocalDateTime(),entity.getTotal(),entity.getProducts());
    }
  

       

        public String eliminaOrdine(Long id) {
            

            if (!ordersRepository.existsById(id)) {
                throw new RuntimeException("Ordine non trovato");
            }

            ordersRepository.deleteById(id);
        
          return "eliminato correttamente";
	

	
    }
}

