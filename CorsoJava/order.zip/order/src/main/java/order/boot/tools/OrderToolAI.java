package order.boot.tools;

import java.util.List;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;

import order.boot.model.response.OrderResponse;
import order.boot.service.OrdersService;

@Component
	public class OrderToolAI {

		private final OrdersService ordersService;

		public OrderToolAI(OrdersService ordersService) {
			super();
			this.ordersService = ordersService;
		}
		
		@Tool(description = """
			    Recupera tutti gli ordini dal database.
			    Per ogni ordine, considera soltanto:
			    - total;
			    - localDateTime.

			    Escludi tutti gli altri campi settandoli a null.
			    Presenta i dati in una struttura di tipo List<OrderResponse>
			    contenente esclusivamente i campi indicati.
			    """)
		public List<OrderResponse> getAllOrders()
		{
			return ordersService.getAllOrders();
		}
}
