package products.project.command;

import java.util.List;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import products.project.model.response.ProductsResponse;
import products.project.service.ProductsService;

@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class RecoveryAllProductsCommand {

	private final ProductsService productsService;

	public RecoveryAllProductsCommand(ProductsService productsService) {
		super();
		this.productsService = productsService;
	}
	
	public List<ProductsResponse> execute()
	{
		return productsService.getAll();
	}
}