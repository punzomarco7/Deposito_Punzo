package products.project.controller;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import products.project.command.RecoveryAllProductsCommand;
import products.project.command.SearchProductsByCriteriaCommand;
import products.project.model.request.OrderRequestModel;
import products.project.model.request.ProductIdRequest;
import products.project.model.response.ProductsResponse;

@RestController
@RequestMapping("/store")
public class ProductController {

	private final BeanFactory beanFactory;

	public ProductController(BeanFactory beanFactory) {
		super();
		this.beanFactory = beanFactory;
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<ProductsResponse>> getAllProducts()
	{
		RecoveryAllProductsCommand command = beanFactory.getBean(RecoveryAllProductsCommand.class);
		return ResponseEntity.ok(command.execute());
	}
	
	@PatchMapping("/extract")
	public ResponseEntity<List<ProductsResponse>> getProductsById(@RequestBody OrderRequestModel orderRequestModel)
	{
		ProductIdRequest productIdRequest = new ProductIdRequest(orderRequestModel.lsIdProduct());
		SearchProductsByCriteriaCommand command = beanFactory.getBean(SearchProductsByCriteriaCommand.class);
		command.setProductIdRequest(productIdRequest);
		return ResponseEntity.ok(command.execute());
	}
	
}