package products.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import products.project.entity.ProductEntity;
import products.project.model.response.ProductsResponse;
import products.project.repository.ProductsRepository;

@Service
public class ProductsService {

	private final ProductsRepository productsRepository;

	public ProductsService(ProductsRepository productsRepository) {
		super();
		this.productsRepository = productsRepository;
	}
	
	public List<ProductsResponse> getAll()
	{
		List<ProductEntity> lsProducts = productsRepository.findAll();
		return lsProducts.stream().map(map -> new ProductsResponse
				(map.getId(), map.getName(), map.getPrice(), map.getAmount()))
				.toList();
	}
	
	public ProductsResponse getById(Long id)
	{
		Optional<ProductEntity> productById = productsRepository.findById(id);
		return productById.isPresent() ? new ProductsResponse(id, 
															  productById.get().getName(), 
															  productById.get().getPrice(),
															  productById.get().getAmount()) : new ProductsResponse(id, null, null, null);
	}
	
	
	public void updateRecord(ProductsResponse productEntity, Integer quantita)
	{
		Optional<ProductEntity> productById = productsRepository.findById(productEntity.id());
		Integer UpdateAmount = productById.get().getAmount() - quantita;
		productById.get().setAmount(UpdateAmount);
		productsRepository.save(productById.get());
	}
}